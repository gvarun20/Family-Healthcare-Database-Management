<?php
return header("location:src/index/index.php");
