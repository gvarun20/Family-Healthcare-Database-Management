<!-- SCRIPTS -->
<!-- JQuery -->
<script type="text/javascript" src="../../public/js/jquery-3.3.1.min.js"></script>
<!-- Bootstrap tooltips -->
<script type="text/javascript" src="../../public/js/popper.min.js"></script>
<!-- Bootstrap core JavaScript -->
<script type="text/javascript" src="../../public/js/bootstrap.min.js"></script>
<!-- MDB core JavaScript -->
<script type="text/javascript" src="../../public/js/mdb.min.js"></script>
<script type="text/javascript" src="../../public/js/tables.js"></script>
<script type="text/javascript" src="../../public/js/sweetalert2.all.min.js"></script>
<script src="../../includes/canvas/canvasjs.min.js"></script>

</body>
<script>
  // SideNav Button Initialization
  $(".button-collapse").sideNav();
  // SideNav Scrollbar Initialization
  var sideNavScrollbar = document.querySelector('.custom-scrollbar');
  var ps = new PerfectScrollbar(sideNavScrollbar);
</script>

</html>