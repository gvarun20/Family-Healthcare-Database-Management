<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>FAMILY HEALTH CARE MANAGEMENT</title>
  <a href="#"><img src="../public/img/fam.jpg" class="img-fluid flex-center"></a>
  <!-- Font Awesome -->

  <!-- Bootstrap core CSS -->
  <link href='../../public/css/all.css' rel="stylesheet">
  <link href="../../public/css/font-awesome.min.css" rel="stylesheet">
  <link href="../../public/css/bootstrap.min.css" rel="stylesheet">
  <link href="../../public/css/sweetalert2.css" rel="stylesheet">
  <link href="../../public/css/style.css" rel="stylesheet">
  <!-- Material Design Bootstrap -->
  <link href="../../public/css/mdb.min.css" rel="stylesheet">
  <!-- Your custom styles (optional) -->
  <link href="../../public/css/style.css" rel="stylesheet">

</head>